//
//  headerView.swift
//  TestParse
//
//  Created by MU IT Program on 3/30/16.
//  Copyright © 2016 Aziz Almeqrin. All rights reserved.
//

import UIKit

class headerView: UICollectionReusableView {
        
    @IBOutlet var userIdlbl: UILabel!
}
