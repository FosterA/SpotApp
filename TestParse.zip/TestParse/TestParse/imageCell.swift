//
//  imageCell.swift
//  TestParse
//
//  Created by MU IT Program on 3/30/16.
//  Copyright © 2016 Aziz Almeqrin. All rights reserved.
//

import UIKit

class imageCell: UICollectionViewCell {
    
    @IBOutlet var picImg: UIImageView!
}
